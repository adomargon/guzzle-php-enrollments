<?php
namespace matriculation\application;

require '../vendor/autoload.php';

include_once($_SERVER['DOCUMENT_ROOT'] . '/matriculation/enrollments/ports/enrollment_repository.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/matriculation/enrollments/repositories/enrollment_repository.php');


use matriculation\enrollments\EnrollmentRepositoryAdapter;
use matriculation\enrollments\EnrollmentRepositoryInterface;
// use matriculation\mockup_data\Student;
// use matriculation\mockup_data\Students;


class Application {
    private EnrollmentRepositoryInterface $enrollmentRepository;

    public function __construct(EnrollmentRepositoryInterface $enrollmentRepository) {
        $this->enrollmentRepository = $enrollmentRepository;
    }

    public function run(): void {
        header("Access-Control-Allow-Origin: *");
        header ("Content-type: application/json; charset=utf-8"); 
        
        $promise = $this->enrollmentRepository->retrieveStudents();        
        $promise->then(
            function ($response) { // $onFulfilled
                try {
                    $statusCode = $response->getStatusCode();
                    $students = $response->getBody()->getContents();
                    header('HTTP/ 200 Students retrieved');
                    echo json_encode(array("status" => "ok", "students" => $students, 'statusCode' => $statusCode));
                    exit();
                } catch (Exception $exc) {
                    header('HTTP/ 400 JSON cannot be parsed.');
                    echo json_encode(array("status" => "error", "message" => "JSON cannot be parsed: $exc"));
                    exit();
                }
            },
            
            function ($reason) { // $onRejected
                header('HTTP/ 400 The promise was rejected.');
                echo json_encode(array("status" => "error", "message" => "The promise was rejected: $reason"));
                exit();
            }
        );
        $promise->wait();
    }
}

$enrollmentRepository = new EnrollmentRepositoryAdapter();
$app = new Application($enrollmentRepository);
$app->run();



?>