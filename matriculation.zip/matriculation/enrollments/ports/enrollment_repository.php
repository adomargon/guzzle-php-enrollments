<?php
namespace matriculation\enrollments;

use Exception;

interface EnrollmentRepositoryInterface {
    function retrieveStudents();
    // function storeEnrollment(string $enrollmentUuid): Promise;
    // function retrieveEnrollments(): Promise;
    // function retrieveEnrollmentByUuid(string $enrollmentUuid): Promise;
}

class EnrollmentRepositoryError extends Exception {
    public function __constructor(string $message) {
        parent::__construct("<<< EnrollmentRepositoryError: $message >>>");
    }
}
?>