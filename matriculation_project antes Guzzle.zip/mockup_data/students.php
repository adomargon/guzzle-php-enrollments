<?php
namespace matriculation\mockup_data;

use ArrayObject;

class Student {
    public string $studentUuid;
    public string $firstName;
    public string $lastName;

    public function __construct(string $studentUuid, string $firstName, string $lastName) {
        $this->studentUuid = $studentUuid;
        $this->firstName = $firstName;
        $this->lastName = $lastName;
    }
}

class Students extends ArrayObject {
    function __construct() {
        $this->append(new Student("1111-1111", "Pepe", "López"));
        $this->append(new Student("2222-2222", "María", "Sánchez"));
        $this->append(new Student("3333-3333", "Juan", "Jiménez"));
    }
}

header("Access-Control-Allow-Origin: *");
header ("Content-type: application/json; charset=utf-8"); 

$students = new Students();
header('HTTP/ 200 Libros obtenidos');
echo json_encode(array("estado" => "exito", "estudiantes" => $students));

?>