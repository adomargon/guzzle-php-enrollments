<?php
namespace matriculation\enrollments;

require_once($_SERVER['DOCUMENT_ROOT'] . '/matriculation/enrollments/ports/enrollment_repository.php');

use matriculation\enrollments\EnrollmentRepositoryInterface;

class EnrollmentRepositoryAdapter implements EnrollmentRepositoryInterface {
    function retrieveStudents() {
        // $running = null;
        // $mh = curl_multi_init();

        // $ch1 = curl_init();
        // curl_setopt($ch1, CURLOPT_URL, 'http://127.0.0.1/mockup_data/students.php');
        // // Other curl options....
        // curl_multi_add_handle($mh, $ch1);

        // do {
        //     curl_multi_exec($mh, $running);
        //     curl_multi_select($mh);
        // } while ($running > 0);

        // $r1 = curl_multi_getcontent($ch1);
        // curl_multi_remove_handle($mh, $ch1);

        // curl_multi_close($mh);   
        // return $r1;     

        $url = 'http://127.0.0.1/mockup_data/students.php';
        $data = array('field1' => 'value', 'field2' => 'value');
        $options = array(
            'http' => array(
                'header'  => "Content-type: application/json\r\n",
                'method'  => 'POST',
                'content' => json_encode($data),
            )
        );

        $context  = stream_context_create($options);
        $result = file_get_contents($url, false, $context);
        $response = json_decode($result);
        return $response;
    }

    // function storeEnrollment(string $enrollmentUuid): Promise {

    // }

    // function retrieveEnrollments(): Promise;
    // function retrieveEnrollmentByUuid(string $enrollmentUuid): Promise;
}


?>