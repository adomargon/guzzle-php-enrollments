<?php
namespace matriculation\application;

include_once($_SERVER['DOCUMENT_ROOT'] . '/matriculation/enrollments/ports/enrollment_repository.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/matriculation/enrollments/repositories/enrollment_repository.php');


use matriculation\enrollments\EnrollmentRepositoryAdapter;
use matriculation\enrollments\EnrollmentRepositoryInterface;
// use matriculation\mockup_data\Student;
// use matriculation\mockup_data\Students;


class Application {
    private EnrollmentRepositoryInterface $enrollmentRepository;

    public function __construct(EnrollmentRepositoryInterface $enrollmentRepository) {
        $this->enrollmentRepository = $enrollmentRepository;
    }

    public function run(): void {
        $students = $this->enrollmentRepository->retrieveStudents();
        
        header("Access-Control-Allow-Origin: *");
        header ("Content-type: application/json; charset=utf-8"); 
        header('HTTP/ 200 Students retrieved');
	    echo json_encode(array("status" => "ok", "students" => $students));
        exit();
        // $promise->then(
        //     function ($students) { // $onFulfilled
        //         header('HTTP/ 200 Students retrieved');
	    //         echo json_encode(array("status" => "ok", "students" => $students));
        //         exit();
        //     },
            
        //     function ($reason) { // $onRejected
        //         header('HTTP/ 400 The promise was rejected.');
        //         echo json_encode(array("status" => "error", "message" => "The promise was rejected: $reason"));
        //         exit();
        //     }
        // );
    }
}

$enrollmentRepository = new EnrollmentRepositoryAdapter();
$app = new Application($enrollmentRepository);
$app->run();



?>