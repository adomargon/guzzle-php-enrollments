<?php
namespace matriculation\common;

use GuzzleHttp\Promise\Promise;

interface QueryInterface {
    public function getClassName(): string;
}

interface QueryHandlerInterface {
    public function handle(QueryInterface $query): Promise;    
}

abstract class QueryAbstract {
    private string $className;

    function __construct(string $className) {
        $this->className = $className;
    }

    public function getClassName(): string {
        return $this->className;
    }
}
?>